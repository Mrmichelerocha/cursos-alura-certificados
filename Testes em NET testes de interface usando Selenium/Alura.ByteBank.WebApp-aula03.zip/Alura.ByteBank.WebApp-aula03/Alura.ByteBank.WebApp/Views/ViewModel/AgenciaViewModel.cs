﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alura.ByteBank.WebApp.Views.ViewModel
{
    public class AgenciaViewModel
    {
    }
}
